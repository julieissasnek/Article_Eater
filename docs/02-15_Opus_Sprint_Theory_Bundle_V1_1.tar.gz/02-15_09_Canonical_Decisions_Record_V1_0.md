# CANONICAL DECISIONS RECORD
## Article Eater — Approved by David, February 15, 2026
## ALL AGENTS: Treat this document as authoritative. Do not deviate.

---

## Decision 1: GapType Enum
**CANONICAL**: `gap_predictor.py` 8-value enum
```
MEDIATION, MECHANISM, BOUNDARY, DIRECTION, INTERACTION,
VALIDATION, UNJUSTIFIED_EDGE, CRITICAL_QUESTION, ARGUMENT_ATTACK
```
All other services (`voi_search.py`, `discovery_funnel.py`) must import this enum.
Stub implementations required for `find_critical_question_gaps()` and `find_argument_attack_gaps()`.

## Decision 2: Template IDs
**CANONICAL**: Short form from summary tables (e.g., `IC_INTEROCEPTIVE_AFFECT_001`)
- Create alias map for long forms (e.g., `IC_INTEROCEPTIVE_AFFECT_CONSTRUCTION_001`)
- Template 31 = `AUD_SCENE_ANALYSIS_001` (Panel III final, not Panel II proposed)

## Decision 3: Tier 1 Framework Count
**CANONICAL**: 10 frameworks
1. PP — Predictive Processing
2. SN — Spatial Navigation / Cognitive Mapping
3. DP — Dual-Process Evaluation
4. DT — DMN/TPN Dynamics
5. NM — Neuromodulatory Systems
6. IC — Interoceptive / Constructionist Affect
7. MS — Memory Systems
8. EC — Embodied Cognition
9. CB — Chronobiological Regulation *(added by Panel II)*
10. MSI — Multisensory Integration *(added by Panel III)*

Update `theory_bootstrap.py` from 8 to 10.

## Decision 4: Pathway Taxonomy
**CANONICAL**: `SUBPERSONAL / PERSONAL_EPISTEMIC / MIXED`
- This is what's implemented in `pathway_classifier.py` and `web_of_belief.py`
- Update `CLAUDE.md` and `IMPLEMENTATION_TASKS.md` to match
- Retire `EXPLICIT / IMPLICIT_COGNITIVE / IMPLICIT_PHYSIOLOGICAL / MIXED` from all docs

## Decision 5: Causal Chain Endpoint Naming
**CANONICAL**:
- In template data structures: `from_variable` / `to_variable`
- In BN bridge layer only: `antecedent` / `consequent` / `mediators`
- Adapter converts between them at the bridge boundary

## Decision 6: Confidence/Quality Stack
**CANONICAL**: Four separate dimensions, never averaged:
1. `extraction_confidence` — How well did AI extract this from the paper?
2. `statistical_confidence` — p-value, CI, effect size (the paper's own numbers)
3. `mechanism_confidence` — Bridging quality + maturity from template chain
4. `epistemic_confidence` — Entrenchment in web of belief (emergent, not assigned)

Legacy field `ae_confidence` maps to `extraction_confidence`.

## Decision 7: Epistemic Certainty Model
**CANONICAL**: ARCH-4 rank-based model in all bridge payloads
- `rank`, `neg_rank`, `warrant_status` are the canonical fields
- `credence` retained as read-only legacy adapter inside AE only
- No new code should write to `credence`

## Decision 8: Theory-Tier Variable Names
**CANONICAL**: Accept reconciliation table from doc 08 as written:
- 9 variables match existing code fields — use as-is
- ~20 new variables created by theory tier — use names from Sprint 7 Theory Artifacts (doc 07)
- 3 overlaps resolved by level distinction:
  - `environment_factors` = extraction-level field (keep)
  - `environmental_threat_cues` = template-level theoretical variable (new)
  - `environmental_legibility` = EC framework variable (new, overlaps SN; independence matrix = 0.5)

---

## Reference Documents (in order of authority)
1. **This file** — naming decisions
2. `02-15_07_Sprint7_Theory_Artifacts_V1_0.md` — framework scopes, independence matrix, seed encodings
3. `02-15_06_Template_Completeness_Audit_Theory_Reference_V1_0.md` — template completeness, prediction grammar, bridging rules
4. `02-15_08_Audit_Synthesis_Recommendations_V1_0.md` — full audit synthesis
5. `02-15_04_Claude_Code_Master_Sprint_Plan_V1_0.md` — sprint structure

---

*Approved: David Kirsh, 2026-02-15*
