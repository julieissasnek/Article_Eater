#!/usr/bin/env bash
# EnvKit Patch Installer — v0.1 → v0.2
# Run from project root where EnvKit v0.1 is installed

set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(pwd)"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
ARCHIVE="_archive/envkit_patch/${TIMESTAMP}"

echo "═══════════════════════════════════════════════════════════════════"
echo "  ENVKIT PATCH INSTALLER — v0.1 → v0.2"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "Project root: $ROOT"
echo "Patch source: $PATCH_DIR"
echo "Archive: $ARCHIVE"
echo ""

# Check if EnvKit v0.1 exists
if [[ ! -f "$ROOT/envkit_bootstrap.sh" ]]; then
    echo "ERROR: EnvKit v0.1 not found in current directory"
    echo "Make sure you're in the project root with EnvKit installed"
    exit 1
fi

# Create archive directory
mkdir -p "$ROOT/$ARCHIVE"

# Function to install file with archive
install_file() {
    local src="$1"
    local dst="$2"
    
    # Archive existing file if present
    if [[ -e "$ROOT/$dst" ]]; then
        mkdir -p "$ROOT/$ARCHIVE/$(dirname "$dst")"
        cp -a "$ROOT/$dst" "$ROOT/$ARCHIVE/$dst"
        echo "  Archived: $dst"
    fi
    
    # Install new file
    mkdir -p "$ROOT/$(dirname "$dst")"
    cp -a "$PATCH_DIR/$src" "$ROOT/$dst"
    echo "  Installed: $dst"
}

echo "▸ Installing bin/ scripts..."
install_file "bin/version.sh" "bin/version.sh"
install_file "bin/test.sh" "bin/test.sh"
install_file "bin/changelog.sh" "bin/changelog.sh"
install_file "bin/context.sh" "bin/context.sh"
install_file "bin/release.sh" "bin/release.sh"
install_file "bin/claude_start.sh" "bin/claude_start.sh"
install_file "bin/claude_diagnose.sh" "bin/claude_diagnose.sh"
install_file "bin/concat_for_claude.sh" "bin/concat_for_claude.sh"

echo ""
echo "▸ Installing .aidev/ config..."
mkdir -p "$ROOT/.aidev"
install_file ".aidev/known_errors.yaml" ".aidev/known_errors.yaml"
install_file ".aidev/claude_memory.md" ".aidev/claude_memory.md"

echo ""
echo "▸ Installing templates/..."
install_file "templates/claude_instructions.md" "templates/claude_instructions.md"
install_file "templates/claude_safe_commands.yaml" "templates/claude_safe_commands.yaml"

echo ""
echo "▸ Installing root files..."
install_file "AGENTS.md" "AGENTS.md"
install_file "envkit/cli.py" "envkit/cli.py"

# Create VERSION.txt if not exists
if [[ ! -f "$ROOT/VERSION.txt" ]]; then
    echo "0.1.0" > "$ROOT/VERSION.txt"
    echo "  Created: VERSION.txt (0.1.0)"
fi

# Create CHANGELOG.md if not exists
if [[ ! -f "$ROOT/CHANGELOG.md" ]]; then
    cat > "$ROOT/CHANGELOG.md" << 'EOF'
# Changelog

## [0.1.0] - Initial

- EnvKit v0.2 patch applied
EOF
    echo "  Created: CHANGELOG.md"
fi

# Make scripts executable
chmod +x "$ROOT/bin/"*.sh 2>/dev/null || true

echo ""
echo "▸ Generating initial context..."
if [[ -x "$ROOT/bin/context.sh" ]]; then
    "$ROOT/bin/context.sh" >/dev/null 2>&1 || true
    echo "  Generated: .aidev/context.md"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  ✓ PATCH APPLIED SUCCESSFULLY"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "New commands available:"
echo "  ./bin/version.sh check     Show version"
echo "  ./bin/version.sh bump      Increment version"
echo "  ./bin/test.sh              Run tests"
echo "  ./bin/claude_start.sh      Bootstrap Claude session"
echo "  ./bin/claude_diagnose.sh   Diagnose errors"
echo "  ./bin/release.sh           Create release"
echo ""
echo "Original commands still work:"
echo "  ./bin/prod_smoke.sh        One truth command"
echo ""
echo "Archived files: $ARCHIVE"
