# EnvKit Patch v0.1 → v0.2

This patch upgrades EnvKit v0.1 to v0.2 with:
- Version governance
- Test integration
- Changelog automation
- AI context generation
- Multi-AI support (Claude + Codex)
- Self-diagnosis with known error patterns
- Release artifact management

## Installation

```bash
# From your project root (where EnvKit v0.1 is installed)
unzip EnvKit_Patch_v0.2.zip
./patch_envkit.sh
```

The patch script will:
1. Archive existing files before replacing
2. Add new scripts to `bin/`
3. Add Claude templates to `templates/`
4. Create `.aidev/` directory with config
5. Update `AGENTS.md` for multi-AI
6. Update `envkit/cli.py`

## New Commands After Patching

```bash
# Version management
./bin/version.sh check      # Show version
./bin/version.sh bump       # Increment patch version

# Testing
./bin/test.sh               # Run test suite

# AI context
./bin/context.sh            # Generate .aidev/context.md

# Claude session
./bin/claude_start.sh       # Bootstrap Claude session
./bin/claude_diagnose.sh "error"  # Diagnose errors

# Release
./bin/release.sh            # Create versioned release

# Original commands still work
./bin/prod_smoke.sh         # One truth command
```

## New CLI Commands

```bash
envkit version              # Show version
envkit bump                 # Increment version
envkit context              # Generate AI context
envkit claude-start         # Bootstrap Claude session
envkit diagnose "error"     # Diagnose error
```

## Files Added

```
bin/
├── version.sh              # Version management
├── test.sh                 # Test runner
├── changelog.sh            # Changelog automation
├── context.sh              # AI context generator
├── release.sh              # Release creator
├── claude_start.sh         # Claude session bootstrap
├── claude_diagnose.sh      # Error diagnosis
└── concat_for_claude.sh    # Prepare files for Claude

.aidev/
├── known_errors.yaml       # Error patterns database
└── claude_memory.md        # Persistent learnings

templates/
├── claude_instructions.md  # Claude guidelines
└── claude_safe_commands.yaml # Command whitelist

CHANGELOG.md                # Version history
VERSION.txt                 # Single source of truth
```

## Compatibility

- Works with existing EnvKit v0.1 installations
- All v0.1 commands continue to work
- Archives replaced files to `_archive/envkit_patch/`
