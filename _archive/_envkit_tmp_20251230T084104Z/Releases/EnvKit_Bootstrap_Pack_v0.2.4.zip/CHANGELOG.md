# Changelog

## [0.2.4] - 2025-12-25

### Fixed / Improved
- Restored `.aidev/` support (`known_errors.yaml`, `claude_memory.md`) for Claude/Codex workflows.
- `envkit_bootstrap.sh` now refreshes the full v0.2 script set in `bin/` (non-destructively archives replaced files).
- Release hygiene: removed accidentally embedded legacy pack content (e.g., `src/EnvKit_Bootstrap_Pack_v0.1/*`) and `.DS_Store`.

### Notes
- This release consolidates the practical stability improvements introduced during the 0.2.x iteration (smoke robustness and release/deploy consistency).

## [0.2.1] - 2025-12-25

### Added
- Default `testing.command` in `envkit.yml` pointing to `./bin/self_test.sh`.
- `bin/deploy_envkit.sh` for non-destructive deployment into a target repo.
- `bin/self_test.sh` so `./bin/test.sh` always has a safe default.

### Changed
- `bin/test.sh` improved parsing of quoted/unquoted YAML command scalars.

## [0.2.0] - 2025-12-25

### Added
- Version governance via `VERSION.txt` and `bin/version.sh`.
- Test runner `bin/test.sh` (configured via `envkit.yml`).
- AI helpers: `bin/context.sh`, `bin/claude_start.sh`, `bin/claude_diagnose.sh`.
- Release helpers: `bin/changelog.sh`, `bin/release.sh`.

