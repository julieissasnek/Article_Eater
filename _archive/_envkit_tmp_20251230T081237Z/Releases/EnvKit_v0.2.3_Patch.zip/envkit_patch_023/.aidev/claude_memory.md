# Claude Memory

Persistent learnings across sessions. Human can review and edit.

## Project Understanding
<!-- Claude: Note key insights about this project -->

## Installation Notes
<!-- Claude: Add any installation quirks discovered -->

## Common Issues & Fixes
<!-- Claude: Add issues you've solved -->

| Issue | Fix |
|-------|-----|
| | |

## User Preferences
<!-- Claude: Note any user preferences about code style, workflow, etc. -->

## Session Log
<!-- Claude: Brief note after each session -->

### Session Template
```
Date: YYYY-MM-DD
Changes:
- 
Issues:
- 
Next:
- 
```

---
*Last updated: (Claude fills this in)*
