# EnvKit Bootstrap Pack v0.2.3

Unzip this pack at the *root* of any repository to add a portable "dev + governance" environment.

## Core entrypoints

- `./envkit_bootstrap.sh` — install/refresh (archives replacements under `_archive/envkit/<timestamp>/`)
- `./bin/prod_smoke.sh` — one truth command (fingerprint → rebuild decision → up → basic checks)
- `./bin/release_and_smoke.sh` — optional release gate then smoke

## Quick start

```bash
unzip -o EnvKit_Bootstrap_Pack_v0.2.3.zip
./envkit_bootstrap.sh
./bin/prod_smoke.sh
```

## v0.2.3 Commands

```bash
# Version management
./bin/version.sh check          # Show current version
./bin/version.sh bump           # Increment patch version

# Testing
./bin/test.sh                   # Run test suite (configured in envkit.yml)

# AI context
./bin/context.sh                # Generate .aidev/context.md

# Claude session
./bin/claude_start.sh           # Bootstrap Claude session
./bin/claude_diagnose.sh "err"  # Diagnose error

# Release
./bin/release.sh                # Create versioned release
```

## For Claude

1. Run `./bin/claude_start.sh` at session start
2. Read `AGENTS.md` for safety rules
3. Read `.aidev/context.md` for project state
4. Use `./bin/claude_diagnose.sh` on errors
5. Update `.aidev/claude_memory.md` at session end

## Files Installed

```
bin/
├── prod_smoke.sh           # ONE TRUTH COMMAND
├── version.sh              # Version management
├── test.sh                 # Test runner
├── context.sh              # AI context generator
├── claude_start.sh         # Claude session bootstrap
├── claude_diagnose.sh      # Error diagnosis
├── release.sh              # Release creator
└── ...

.aidev/
├── known_errors.yaml       # Error patterns for diagnosis
└── claude_memory.md        # Persistent learnings

templates/
├── claude_instructions.md
├── claude_safe_commands.yaml
├── codex_config.toml
└── codex_default.rules
```

## Notes

- `./bin/test.sh` reads `testing.command` from `envkit.yml`
- Docker is required for `runtime.kind: docker_compose` workflows
- Customize `envkit.yml` for your project type

## New in v0.2.3

- Fixed: `.aidev/` directory now included with `known_errors.yaml` and `claude_memory.md`
- Fixed: `envkit_bootstrap.sh` now installs all v0.2 scripts
- Added: Changelog validation for releases
