#!/usr/bin/env bash
# EnvKit v0.2.3 Patch — Fixes missing .aidev and bootstrap
# Run from the EnvKit directory (where envkit_bootstrap.sh exists)

set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(pwd)"

echo "═══════════════════════════════════════════════════════════════════"
echo "  ENVKIT v0.2.3 PATCH"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "Target: $ROOT"
echo "Patch:  $PATCH_DIR"
echo ""

# Verify we're in an EnvKit directory
if [[ ! -f "$ROOT/VERSION.txt" ]]; then
    echo "ERROR: VERSION.txt not found. Are you in the EnvKit directory?"
    exit 1
fi

# Create .aidev if missing
mkdir -p "$ROOT/.aidev"

# Copy .aidev files
echo "Installing .aidev files..."
cp -a "$PATCH_DIR/.aidev/known_errors.yaml" "$ROOT/.aidev/" && echo "  ✓ .aidev/known_errors.yaml"
cp -a "$PATCH_DIR/.aidev/claude_memory.md" "$ROOT/.aidev/" && echo "  ✓ .aidev/claude_memory.md"

# Update envkit_bootstrap.sh
echo ""
echo "Updating envkit_bootstrap.sh..."
cp -a "$PATCH_DIR/envkit_bootstrap.sh" "$ROOT/envkit_bootstrap.sh" && echo "  ✓ envkit_bootstrap.sh"
chmod +x "$ROOT/envkit_bootstrap.sh"

# Update README.md
echo ""
echo "Updating README.md..."
cp -a "$PATCH_DIR/README.md" "$ROOT/README.md" && echo "  ✓ README.md"

echo ""
echo "═══════════════════════════════════════════════════════════════════"
echo "  ✓ PATCH APPLIED"
echo "═══════════════════════════════════════════════════════════════════"
echo ""
echo "Fixed:"
echo "  • Added .aidev/known_errors.yaml"
echo "  • Added .aidev/claude_memory.md"
echo "  • Updated envkit_bootstrap.sh to install all v0.2 scripts"
echo "  • Updated README.md to v0.2.3"
echo ""
echo "Next: ./bin/claude_start.sh"
