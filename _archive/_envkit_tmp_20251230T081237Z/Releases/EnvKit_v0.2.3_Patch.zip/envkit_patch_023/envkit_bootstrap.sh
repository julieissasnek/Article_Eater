#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

ts="$(date +%Y%m%d_%H%M%S)"
ARCH="_archive/envkit/${ts}"
mkdir -p "$ARCH"

put_file() {
  local src="$1"
  local dst="$2"
  [[ "$src" == "$dst" ]] && return 0
  if [[ -e "$dst" ]]; then
    mkdir -p "$ARCH/$(dirname "$dst")"
    cp -a "$dst" "$ARCH/$dst"
  fi
  mkdir -p "$(dirname "$dst")"
  cp -a "$src" "$dst"
}

echo "== EnvKit bootstrap v0.2.3 =="
echo "Repo: $ROOT"
echo "Archive: $ARCH"

# Create directories
mkdir -p bin envkit templates .aidev _archive/envkit _archive/_smoke

# Core config files (only if not present)
[[ ! -f envkit.yml ]] && [[ -f "envkit.yml" ]] && put_file "envkit.yml" "envkit.yml"
[[ ! -f AGENTS.md ]] && [[ -f "AGENTS.md" ]] && put_file "AGENTS.md" "AGENTS.md"
[[ ! -f VERSION.txt ]] && echo "0.1.0" > VERSION.txt

# All bin scripts (always update)
for script in prod_smoke.sh release_and_smoke.sh version.sh test.sh \
              context.sh changelog.sh release.sh self_test.sh \
              claude_start.sh claude_diagnose.sh concat_for_claude.sh \
              deploy_envkit.sh; do
    if [[ -f "bin/$script" ]]; then
        put_file "bin/$script" "bin/$script"
    fi
done

# Templates (always update)
if [[ -d "templates" ]]; then
    for tmpl in templates/*; do
        [[ -f "$tmpl" ]] && put_file "$tmpl" "$tmpl"
    done
fi

# .aidev files (only if not present, to preserve user edits)
if [[ -d ".aidev" ]]; then
    for aifile in .aidev/*; do
        if [[ -f "$aifile" ]]; then
            dst_file="$(basename "$aifile")"
            if [[ ! -f ".aidev/$dst_file" ]]; then
                put_file "$aifile" ".aidev/$dst_file"
            fi
        fi
    done
fi

# Make scripts executable
chmod +x bin/*.sh envkit_bootstrap.sh 2>/dev/null || true

echo ""
echo "OK: EnvKit v0.2.3 installed."
echo ""
echo "Installed:"
echo "  bin/prod_smoke.sh        — ONE TRUTH COMMAND"
echo "  bin/version.sh           — version management"
echo "  bin/test.sh              — test runner"
echo "  bin/claude_start.sh      — Claude session bootstrap"
echo "  bin/claude_diagnose.sh   — error diagnosis"
echo "  .aidev/known_errors.yaml — error patterns"
echo "  .aidev/claude_memory.md  — persistent learnings"
echo ""
echo "Next: ./bin/prod_smoke.sh"
