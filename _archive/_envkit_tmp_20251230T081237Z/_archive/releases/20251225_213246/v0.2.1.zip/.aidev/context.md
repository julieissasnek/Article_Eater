# Project Context (Auto-Generated)

Generated: 2025-12-25 19:49:07

## Current State
- Version: 0.2.1
- Path: /Users/davidusa/REPOS/EnvKit

## Directory Structure
```
./.aidev/claude_memory.md
./.aidev/context.md
./.aidev/known_errors.yaml
./bin/changelog.sh
./bin/claude_diagnose.sh
./bin/claude_start.sh
./bin/concat_for_claude.sh
./bin/context.sh
./bin/deploy_envkit.sh
./bin/prod_smoke.sh
./bin/release_and_smoke.sh
./bin/release.sh
./bin/self_test.sh
./bin/test.sh
./bin/version.sh
./CHANGELOG.md
./deconcat.py
./EnvKit_Bootstrap_Pack_v0.1.zip
./EnvKit_Bootstrap_Pack_v0.2.1.zip
./envkit_bootstrap.sh
./EnvKit_Patch_v0.2.zip
./envkit.yml
./envkit/__init__.py
./envkit/cli.py
./envkit/requirements.txt
./PROJECT_CONSTITUTION.md
./README.md
./Releases/.DS_Store
./Releases/EnvKit_Bootstrap_Pack_v0.2.zip
./templates/claude_instructions.md
```

## Key Commands
- `./bin/prod_smoke.sh` — verify everything
- `./bin/test.sh` — run tests
- `./bin/version.sh bump` — increment version
