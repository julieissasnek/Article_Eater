# Claude Memory

Persistent learnings across sessions. Human can review and edit.

## Installation Notes
<!-- Add installation quirks -->

## Common Issues & Fixes
<!-- Add issues solved -->

## Session Log
<!-- Brief notes after each session -->

---
*Last updated: (Claude fills this in)*
